#include "src/core_functions/scalar/operators/bitwise.cpp"

