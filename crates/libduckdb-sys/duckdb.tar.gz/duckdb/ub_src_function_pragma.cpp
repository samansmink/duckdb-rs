#include "src/function/pragma/pragma_functions.cpp"

#include "src/function/pragma/pragma_queries.cpp"

